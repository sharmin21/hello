package com.example.user.sqlliteapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText etName;
    private EditText etPrice;
    private EditText etquantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName=findViewById (R.id.etName);
        etPrice = findViewById (R.id.etPrice);
        etquantity=findViewById(R.id.etquantity);
    }

    public void btn_AddToDb(View view) {

        String name = etName.getText ().toString ();
        String price = etPrice.getText ().toString ();
        String quantity = etquantity.getText ().toString ();

        DatabaseQuery dbQuery = new DatabaseQuery (MainActivity.this);
        long product = dbQuery.insertData (new Product (name, price,quantity));
        Toast.makeText (this, "" + dbQuery.getTotalItem (), Toast.LENGTH_SHORT).show ();
        startActivity (new Intent(MainActivity.this, ListActivity.class));

    }
}
