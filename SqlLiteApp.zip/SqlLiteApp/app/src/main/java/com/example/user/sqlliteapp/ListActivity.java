package com.example.user.sqlliteapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

public class ListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProductAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        recyclerView=findViewById(R.id.recyclerView);
        DatabaseQuery dbQuery = new DatabaseQuery (this);
        adapter = new ProductAdapter (this, dbQuery.getAllData ());
        recyclerView.setAdapter (adapter);
        recyclerView.setLayoutManager (new LinearLayoutManager(this));

    }
}
