package com.example.user.sqlliteapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Toast;

import java.util.ArrayList;

public class DatabaseQuery {
    private Context context;
    private DatabaseHelper dbhelper  ;

    public DatabaseQuery(Context context) {
        this.context = context;
        dbhelper = DatabaseHelper.getDBHelper (context);
    }
    public long insertData(Product product) {
        long id = -1;
        SQLiteDatabase db = dbhelper.getWritableDatabase ();

        ContentValues contentValues = new ContentValues ();

        contentValues.put (DatabaseHelper.COLUMN_NAME, product.getName ());
        contentValues.put (DatabaseHelper.COLUMN_PRICE, product.getPrice ());
        contentValues.put (DatabaseHelper.COLUMN_QUANTITY, product.getQuantity ());

        id = db.insert (DatabaseHelper.TABLE_NAME, null, contentValues);

        if (id != -1) {
            Toast.makeText (context, "Data Inserted", Toast.LENGTH_SHORT).show ();
        } else {
            Toast.makeText (context, "Failed to insert", Toast.LENGTH_SHORT).show ();
        }
        return id;
    }

    public long getTotalItem() {
        SQLiteDatabase db = dbhelper.getReadableDatabase ();
        return DatabaseUtils.queryNumEntries (db, DatabaseHelper.TABLE_NAME);
    }

    public ArrayList<Product> getAllData() {
        ArrayList<Product> products = new ArrayList<> ();

        SQLiteDatabase db = dbhelper.getReadableDatabase ();

        String query = "SELECT * FROM " + DatabaseHelper.TABLE_NAME;

        Cursor cursor = db.rawQuery (query, null);

        if (cursor != null) {
            if (cursor.moveToFirst ()) {
                do {
                    String id = cursor.getString (cursor.getColumnIndex (DatabaseHelper.COLUMN_ID));
                    String name = cursor.getString (cursor.getColumnIndex (DatabaseHelper.COLUMN_NAME));
                    String price = cursor.getString (cursor.getColumnIndex (DatabaseHelper.COLUMN_PRICE));
                    String quantity = cursor.getString (cursor.getColumnIndex (DatabaseHelper.COLUMN_QUANTITY));
                    products.add (new Product (id, name, price,quantity));
                }
                while (cursor.moveToNext ());
            }
        }

        return products;
    }
    public void updateItem(Product product) {

        SQLiteDatabase db = dbhelper.getWritableDatabase ();

        ContentValues contentValues = new ContentValues ();

        contentValues.put (DatabaseHelper.COLUMN_NAME, product.getName ());
        contentValues.put (DatabaseHelper.COLUMN_PRICE, product.getPrice ());
        contentValues.put (DatabaseHelper.COLUMN_QUANTITY, product.getQuantity ());


        db.update (DatabaseHelper.TABLE_NAME, contentValues, DatabaseHelper.COLUMN_ID + "=?", new String[]{product.getId ()});

    }
    public void deleteItem(String id) {
        SQLiteDatabase db = dbhelper.getWritableDatabase ();
        db.delete (DatabaseHelper.TABLE_NAME, DatabaseHelper.COLUMN_ID + "=?", new String[]{id});
    }}
