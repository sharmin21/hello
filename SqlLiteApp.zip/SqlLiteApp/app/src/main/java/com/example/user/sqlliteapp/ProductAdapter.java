package com.example.user.sqlliteapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {
    private Context context;
    private ArrayList<Product> products;

    public ProductAdapter(Context context, ArrayList<Product> products) {
        this.context = context;
        this.products = products;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, final int position) {
        holder.tv_Name.setText(products.get(position).getName());
        holder.tv_Price.setText(products.get(position).getPrice());
        holder.tv_Quantity.setText(products.get(position).getQuantity());
        holder.btn_Delete.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                DatabaseQuery dbquery = new DatabaseQuery(context);
                dbquery.deleteItem(products.get(position).getId());

                RecyclerView recyclerView = ((Activity) context).findViewById(R.id.recyclerView);

                DatabaseQuery databaseQuery = new DatabaseQuery(context);
                ArrayList<Product> products = databaseQuery.getAllData();
                ProductAdapter adapter = new ProductAdapter(context, products);

                recyclerView.setAdapter(adapter);
                recyclerView.setLayoutManager(new LinearLayoutManager(context));
            }
        });
        holder.btn_Edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UpdateActivity.class);
                intent.putExtra("id", products.get(position).getId());
                intent.putExtra("name", products.get(position).getName());
                intent.putExtra("price", products.get(position).getPrice());
                intent.putExtra("quantity", products.get(position).getQuantity());

                context.startActivity(intent);
                ((Activity) context).finish();
            }
        });
    }

    @Override
    public int getItemCount() {
        return products.size();
    }

    public class ProductViewHolder extends RecyclerView.ViewHolder {
        public TextView tv_Name;
        public TextView tv_Price;
        public TextView tv_Quantity;
        public Button btn_Delete;
        public Button btn_Edit;

        public ProductViewHolder(View itemView) {
            super(itemView);
            tv_Name = itemView.findViewById(R.id.tv_name);
            tv_Price = itemView.findViewById(R.id.tv_price);
            tv_Quantity = itemView.findViewById(R.id.tv_quantity);

            btn_Delete = itemView.findViewById(R.id.btn_delete);
            btn_Edit = itemView.findViewById(R.id.btn_edit);
        }
    }
}