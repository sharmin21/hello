package com.example.user.sqlliteapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity {

    private EditText et_name;
    private EditText et_price;
    private EditText et_quantity;


    private String id, name, price,quantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        id = getIntent ().getStringExtra ("id");
        name = getIntent ().getStringExtra ("name");
        price = getIntent ().getStringExtra ("price");
        quantity = getIntent ().getStringExtra ("quantity");

        et_name = findViewById (R.id.edit_name);
        et_price = findViewById (R.id.edit_price);
        et_quantity = findViewById (R.id.edit_quantity);

        et_name.setText (name);
        et_price.setText (price);
        et_quantity.setText (quantity);
    }

    public void btn_update(View view) {
        DatabaseQuery databaseQuery = new DatabaseQuery (this);
        name = et_name.getText ().toString ();
        price = et_price.getText ().toString ();
        quantity = et_quantity.getText ().toString ();

        databaseQuery.updateItem (new Product (id, name, price,quantity));

        Toast.makeText (this, "Updated Successfully", Toast.LENGTH_SHORT).show ();
        startActivity (new Intent(UpdateActivity.this, ListActivity.class));

    }
}
